import { render } from "solid-js/web";
import { createSignal } from "solid-js";
  const [count, setCount] = createSignal(0);

function Counter() {
  const increment = () => setCount(count() + byHowMuch());
const [byHowMuch, setByHowMuch] = createSignal(1);

  console.log('Hello World');

  return (
    <div>
    <input type="number" value={byHowMuch()} onInput={(e) => setByHowMuch(Number(e.currentTarget.value))} />
    <button type="button" onClick={increment}>
      {count()}
    </button>
    </div>
  );
}

function App() {
  return (
    <>
    <Counter />
    <Counter />
    <Counter />
    <Counter />
    <Counter />
    </>
  )
}

render(() => <App />, document.getElementById("app"));
